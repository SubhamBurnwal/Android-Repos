package subham.simpleapp;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {
    static boolean isBannerDown;
    static boolean isSimpleButtonDown;
    static boolean firstClick;
    Button wasClicked;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        setContentView(R.layout.activity_main);
        isBannerDown = false;
        isSimpleButtonDown = false;
        firstClick = true;

        final ImageButton pullDownButton = findViewById(R.id.pullDown_btn3);
    }

    protected void onResume(){
        super.onResume();
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        setContentView(R.layout.activity_main);
    }
    public void onClickBannerButton(View view) {
        pullBanner(false);
    }
    public void pullBanner(boolean needsReset) {
        ImageButton pullDownButton = findViewById(R.id.pullDown_btn3);
        LinearLayout pDownBanner = findViewById(R.id.pullDown);
        FrameLayout.LayoutParams flp;

        if(isSimpleButtonDown) {
            pullSimpleButton(wasClicked, false);
            isSimpleButtonDown = false;
        }

        if(isBannerDown || needsReset) {
            for(int i=1;i<pDownBanner.getChildCount();i++)
                pDownBanner.getChildAt(i).setVisibility(View.GONE);
         /*
            ResizeAnimation resizeAnimation = new ResizeAnimation(
                pDownBanner,
                FrameLayout.LayoutParams.WRAP_CONTENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            );
            resizeAnimation.setDuration(2000);
            pDownBanner.startAnimation(resizeAnimation);
        */
            flp = new FrameLayout.LayoutParams(pDownBanner.getWidth(), FrameLayout.LayoutParams.WRAP_CONTENT);
            pullDownButton.setScaleY(1);
        }
        else {
            for(int i=0;i<pDownBanner.getChildCount()-1;i++)
                pDownBanner.getChildAt(i).setVisibility(View.VISIBLE);
        /*
            ResizeAnimation resizeAnimation = new ResizeAnimation(
                pDownBanner,
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
            );
            resizeAnimation.setDuration(2000);
            pDownBanner.startAnimation(resizeAnimation);
        */
            flp = new FrameLayout.LayoutParams(pDownBanner.getWidth(), FrameLayout.LayoutParams.MATCH_PARENT);
            pullDownButton.setScaleY(-1);
        }
        pDownBanner.setLayoutParams(flp);
        flp.gravity = Gravity.END;
        isBannerDown = !isBannerDown;
    }
    public void onClickSimpleButton(View view) {
        Button btn = (Button) view;
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) btn.getLayoutParams();

        if(isBannerDown) pullBanner(true);

        if (firstClick) {
            pullSimpleButton(btn,true);
            isSimpleButtonDown = true;
        } else if (isSimpleButtonDown) {
            if (wasClicked.equals(btn)) {
                pullSimpleButton(wasClicked, false);
                isSimpleButtonDown = false;
            }
            else{
                pullSimpleButton(wasClicked, false);
                pullSimpleButton(btn,true);
                isSimpleButtonDown = true;
            }
        }
        else if(!isSimpleButtonDown){
            pullSimpleButton(btn,true);
            isSimpleButtonDown = true;
        }
        wasClicked = btn;
        firstClick = false;

        switch(btn.getId()){
            case R.id.button1: startActivity(new Intent(this, GameActivity.class)); break;
            case R.id.button2: break;
            case R.id.button3: startActivity(new Intent(this, GuideActivity.class)); break;
            default: break;
        }
    }
    public static void pullSimpleButton(View view, boolean push){
        ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
        view.setLayoutParams(new LinearLayout.LayoutParams(push?LinearLayout.LayoutParams.MATCH_PARENT:LinearLayout.LayoutParams.WRAP_CONTENT, view.getHeight()));
        setMarginsVertical(view, lp.bottomMargin);
    }
    public static void setMarginsVertical(View view, int val){
        if(view.getLayoutParams() instanceof ViewGroup.MarginLayoutParams){
            ViewGroup.MarginLayoutParams params = (ViewGroup.MarginLayoutParams) view.getLayoutParams();
            params.setMargins(0, val, 0, val);
            view.requestLayout();
        }
    }
    /*public static float dpToPx(float dp, Context context){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float px = dp * ((float)metrics.densityDpi / DisplayMetrics.DENSITY_DEVICE_STABLE);
        return  px;
    }*/
}

