package subham.simpleapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;


public class GameView extends SurfaceView implements Runnable {

    //the game thread
    private Thread gameThread = null;
    //boolean variable to track if the game is playing or not
    volatile boolean playing;
    private boolean pressedBack;

    //our game-play elements as objects
    private Entity ball;
    private myLine myPath;
//    Queue<Point> pArray;

    //our drawing tools as objects
    private Paint paint, pointPaint;
    private SurfaceHolder surfaceHolder;
    private Point MAX, ORIG;

    //Class constructor
    public GameView(Context context, Point screenSize) {
        super(context);
        ORIG = new Point(0,0);
        MAX = new Point(screenSize);
        //initialising elements
        Bitmap bitmap = BitmapFactory.decodeResource(context.getResources(), R.drawable.player);
        ball = new Entity(context, "Basic Ball", 4, bitmap, 10, MAX.x/3, MAX.y/2);
        ball.setPos(ball.origin());
        //initialising tools
        surfaceHolder = getHolder();
        paint = new Paint();
        pointPaint = new Paint();
        myPath = new myLine(ball.pos(),ball.target());
    }

    @Override
    public void run() {
        pressedBack = false;
        int i = 0;
        int v = 23;
        ball.setVelocity(v, v);
//        int maxV = 30;
        int toSkip = 35;
        while (playing) {
            //to draw the frame
            if(!myPath.isTraced()){
                if(i%toSkip==0) {
                    draw();
                }
                update(myPath.getNext(ball.pos()));
            }
            ball.set_collided(false);
            //to control stuff like framerate
            control(0);
            i++;
            if(i > 1000) i = 0;
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent motionEvent){
        int x, y;
        switch(motionEvent.getAction() & MotionEvent.ACTION_MASK){
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_DOWN:
            case MotionEvent.ACTION_MOVE:
                x = (int)motionEvent.getX();
                y = (int)motionEvent.getY();
                if(x + ball.width() > MAX.x) x = MAX.x - ball.width();
                if(y + ball.height() > MAX.y) x = MAX.y - ball.height();
                ball.setTarget(x, y);
                myPath.init(ball.pos(), ball.target());
        }
        return true;
    }
    private void update(Point dLoc) {
            ball.setPos(dLoc);
    }
    private void draw() {
        if(surfaceHolder.getSurface().isValid()){
            Canvas canvas = surfaceHolder.lockCanvas();
            canvas.drawColor(Color.BLACK);
            physics phys = new physics();
//            Iterator it = pArray.iterator();

//            while(it.hasNext()){
                pointPaint.setStrokeWidth(2);
                pointPaint.setColor(Color.WHITE);
                //Point next = new Point((Point)it.next());
                canvas.drawLine(ball.origin().x, ball.origin().y, ball.pos().x, ball.pos().y, pointPaint);
                pointPaint.setColor(Color.RED);
                canvas.drawLine(ball.pos().x, ball.pos().y, ball.target().x, ball.target().y, pointPaint);
                pointPaint.setColor(Color.GREEN);
                canvas.drawLine(myPath.getA().x, myPath.getA().y, myPath.getB().x, myPath.getB().y, pointPaint);

//            }

            canvas.drawBitmap(ball.bitmap(), ball.pos().x - ball.height()/2, ball.pos().y - ball.width()/2, paint);

            paint.setColor(Color.WHITE);
            paint.setTextSize(20);
            String ballOrigin = "   ball.origin(): " + ball.origin();
            String ballPosition = "   ball.pos(): " + ball.pos();
            String ballTarget = "   ball.target(): " + ball.target();
            String resolution = "   MAX: " + MAX;
            String ballPath = "   ballPath.A" + myPath.getA() + "   ballPath.B" + myPath.getB();

            String x1 = ballOrigin + resolution;
            String x2 = ballPosition + ballTarget + ballPath;
            canvas.drawText(x1, 10, 30, paint);
            canvas.drawText(x2, 10, 60, paint);

            surfaceHolder.unlockCanvasAndPost(canvas);
        }
    }
    private void control(int millis) {
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
    public void pause() {
        //when the game is paused
        //setting the variable to false
        playing = false;
        try {
            //stopping the thread
            gameThread.join();
        } catch (InterruptedException e) {
            e.fillInStackTrace();
        }
    }
    public void resume() {
        //when the game is resumed
        //starting the thread again
        playing = true;
        gameThread = new Thread(this);
        gameThread.start();
    }
}