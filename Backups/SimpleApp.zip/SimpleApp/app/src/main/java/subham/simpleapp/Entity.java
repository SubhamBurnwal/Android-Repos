package subham.simpleapp;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Point;

import static java.lang.Math.abs;
import static java.lang.Math.pow;
import static java.lang.Math.round;
import static java.lang.Math.sqrt;

class myLine {
    myLine() {
        A = new Point();
        B = new Point();
        _isEmpty = true;
    }

    myLine(Point start, Point end) {
        A = new Point(start);
        B = new Point(end);
        _init();
    }

    public void setA(Point start) {
        A = start;
        _init();
    }

    public void setB(Point end) {
        B = end;
        _init();
    }

    public void init(Point start, Point end) {
            A = start;
            B = end;
            _init();
    }

    private void _init() {
        _isEmpty = false;
        traced = false;
        w = B.x - A.x;
        h = B.y - A.y;

        if (w < 0) dx = -1;
        else if (w > 0) dx = 1;
        else dx = 0;
        if (h < 0) dy = -1;
        else if (h > 0) dy = 1;
        else dy = 0;

        if (abs(h) >= abs(w)) error = abs(2 * w) - abs(h);
        else if (abs(w) > abs(h)) error = 2 * abs(h) - abs(w);
    }

    public boolean isTraced() {
        return traced;
    }

    public boolean isEmpty() {
        return _isEmpty;
    }

    private boolean _isEmpty;
    private boolean traced;
    private Point A;
    private Point B;
    private int dx, dy, w, h, error;

    public Point getNext(Point last) {
        traced = false;
        if (!last.equals(B)) {
            last = predict(last);
        } else traced = true;
        return last;
    }

    public Point getA() {
        return A;
    }

    public Point getB() {
        return B;
    }

    private Point predict(Point next) {
        int x = next.x, y = next.y;

        if (abs(w) > abs(h)) {
            x += dx;
            if (error >= 0) {
                y += dy;
                error -= abs(2 * w);
            }
            error += abs(2 * h);
        } else if (abs(h) > abs(w)) {
            y += dy;
            if (error >= 0) {
                x += dx;
                error -= abs(2 * h);
            }
            error += abs(2 * w);
        } else {
            x = next.x + dx;
            y = next.y + dy;
        }

        next.set(x, y);
        return next;
    }
}


class physics {
    Point relativeTo(Point Target, Point Origin) {
        Point relativePt = new Point(Origin.x + Target.x, Origin.y + Target.y);
        return relativePt;
    }

    Point relativeToZero(Point Target, Point Origin) {
        Point relativePt = new Point(Target.x - Origin.x, Target.y - Origin.y);
        return relativePt;
    }

    double getDistanceBetween(Point point1, Point point2) {
        double x_dist_sq = pow(point1.x - point2.x, 2);
        double y_dist_sq = pow(point1.y - point2.y, 2);
        double dist = sqrt(x_dist_sq + y_dist_sq);
        return dist;
    }

    /*Point getNextPoint(Point A, Point B) {
        int w = B.x - A.x;
        int h = B.y - A.y;
        if(abs(h) > abs(w)) {
            if(w!=0){
                double length = getDistanceBetween(A, B);
                double x = w/length + A.x;
                A.x = (int)round(x);
            }
            if(h<0) A.y--;
            else A.y++;
        }
        else if(abs(w) > abs(h)) {
            if(h!=0) {
                double length = getDistanceBetween(A, B);
                double y = h / length + A.y;
                A.y = (int)round(y);
            }
            if(w<0) A.x--;
            else A.x++;
        }
        else {
            if(w<0) A.x--; else A.x++;
            if(h<0) A.y--; else A.y++;
        }

        return A;
    }*/
    double getMagnitude(double alongX, double alongY) {
        return sqrt(pow(alongX, 2) + pow(alongY, 2));
    }

    double getMagnitude(Point vector) {
        return sqrt(pow(vector.x, 2) + pow(vector.y, 2));
    }
}

class Entity {
    private String _name;
    private Bitmap _bitmap;
    private int _radius;
    private int _mass;
    private Point _velocity;
    private Point _bounds;
    private Point _origin;
    private Point _pos;
    private Point _target;
    private boolean _collided;
    private boolean _accelerating;
    private Point _acceleration;

    Entity(Context context) {
    }

    Entity(Context context, String entity_name, int entity_mass, Bitmap bitmap, int entity_radius, int xOrigin, int yOrigin) {
        _name = entity_name;
        _radius = entity_radius;
        _mass = entity_mass;
        _bitmap = bitmap;
        _bitmap.setHasAlpha(true);
        _velocity = new Point();
        _origin = new Point(xOrigin, yOrigin);
        _collided = false;
        _accelerating = false;
        _acceleration = new Point(0, 0);
    }

    Entity(Context context, String entity_name, int entity_mass, Bitmap bitmap, int entity_height, int entity_width) {
        _name = entity_name;
        _mass = entity_mass;
        _bounds = new Point(entity_width, entity_height);
        _bitmap = bitmap;
        _bitmap.setHasAlpha(true);

        _velocity = new Point();
        _collided = false;
        _accelerating = false;
        _acceleration = new Point(0, 0);
    }

    public String name() {
        return _name;
    }

    public Bitmap bitmap() {
        return _bitmap;
    }

    public boolean collided() {
        return _collided;
    }

    public void set_collided(boolean condition) {
        _collided = condition;
    }

    public Point origin() {
        return _origin;
    }

    public Point pos() {
        if (_pos == null)
            return _origin;
        else
            return _pos;
    }

    public int radius() {
        return _radius;
    }

    public Point velocity() {
        return _velocity;
    }

    public int height() {
        return _bitmap.getHeight();
    }

    public int width() {
        return _bitmap.getWidth();
    }

    public void setOrigin(Point origin) {
        _origin.set(origin.x, _origin.y);
    }

    public void setOrigin(int x, int y) {
        _origin.set(x, y);
    }

    public void setPos(Point pos) {
        if (_pos == null) _pos = new Point();
        _pos.set(pos.x, pos.y);
    }

    public void setPos(int x, int y) {
        _pos.set(x, y);
    }

    public Point target() {
        if (_target == null)
            if (_pos == null)
                return _origin;
            else
                return _pos;
        else
            return _target;
    }

    public void setTarget(Point pos) {
        if (_target == null)
            _target = new Point();
        _target.set(pos.x, pos.y);
    }

    public void setTarget(int x, int y) {
        if (_target == null)
            _target = new Point();
        _target.set(x, y);
    }

    public void accelerate() {
        _velocity.x += _acceleration.x;
        _velocity.y += _acceleration.y;
    }

    public boolean accelerating() {
        return _accelerating;
    }

    public void setAcceleration(int xAcceleration, int yAcceleration, boolean active) {
        _accelerating = active;
        _acceleration.set(xAcceleration, yAcceleration);
    }

    public void setAcceleration(boolean active) {
        _accelerating = active;
    }

    public void setVelocity(int xVelocity, int yVelocity) {
        _velocity.set(xVelocity, yVelocity);
    }
}