package com.intraining.subham.example;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    private int i = 0;
    private boolean props[] = new boolean[]{false,false,false,false};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);
        final View main = findViewById(R.id.MainPage);

        // Example of a call to a native method
        //TextView tv = (TextView) findViewById(R.id.sample_text);
        //tv.setText(stringFromJNI());


        //List of widgets for access
        final Button playB, settingB, quitB;
        final ImageButton prevB, nextB, backB;
        final Switch tutorialToggle, musicToggle, hapticToggle, sfxToggle;
        final TextView saveSettingOption;

        //Linking of widgets
        playB = findViewById(R.id.play);
        settingB = findViewById(R.id.settings);
        quitB = findViewById(R.id.quit);
        prevB = findViewById(R.id.previousBtn);
        nextB = findViewById(R.id.nextBtn);
        backB = findViewById(R.id.backBtn);


        tutorialToggle = findViewById(R.id.tutorialSwitch);
        musicToggle = findViewById(R.id.musicSwitch);
        hapticToggle = findViewById(R.id.hapticSwitch);
        sfxToggle = findViewById(R.id.sfxSwitch);

        saveSettingOption = findViewById(R.id.saveOption);

        props[0] = true;    //tutorial
        props[1] = true;    //music
        props[2] = false;   //haptics
        props[3] = true;    //sfx

        //Methods for widgets

        //HOMEPAGE
        playB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                RelativeLayout OptLayout;
                i = 0;
                //ImageView articleImg = findViewById(R.id.contentImage);
                TextView articleTitle = findViewById(R.id.contentTopic);
                TextView articleText = findViewById(R.id.contentArticle);
                articleTitle.setText(getResources().getStringArray(R.array.titles)[i]);
                articleText.setText(getResources().getStringArray(R.array.articles)[i]);
                //articleImg.setImageDrawable(getResources().getStringArray(R.array.articles)[i]);
                i++;

                OptLayout = findViewById(R.id.ArticlesPage);
                OptLayout.setVisibility(View.VISIBLE);

                //this thing .getParent().bringChildToFront(child name);
            }
        });
        settingB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                LinearLayout OptLayout;
                OptLayout = findViewById(R.id.OptionsPage);
                OptLayout.setVisibility(View.VISIBLE);
            }
        });
        quitB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                finishActivity(0); //not recommended, equivalent to force close
            }
        });

        //SETTINGS PAGE
        tutorialToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                props[0] = tutorialToggle.isChecked();
            }
        });
        musicToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                props[1] = musicToggle.isChecked();
            }
        });
        hapticToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                if (main.isHapticFeedbackEnabled()) {
                    main.setHapticFeedbackEnabled(false);
                    props[2] = false;
                } else {
                    main.setHapticFeedbackEnabled(true);
                    props[2] = true;
                }
            }
        });
        sfxToggle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                props[3] = sfxToggle.isChecked();
            }
        });
        saveSettingOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                LinearLayout OptLayout;
                OptLayout = findViewById(R.id.OptionsPage);
                OptLayout.setVisibility(View.GONE);
            }
        });


        //ARTICLES PAGE
        prevB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (android.view.View view){
                if(i > 0){
                //ImageView articleImg = findViewById(R.id.contentImage);
                TextView articleTitle = findViewById(R.id.contentTopic);
                TextView articleText = findViewById(R.id.contentArticle);
                articleTitle.setText(getResources().getStringArray(R.array.titles)[i]);
                articleText.setText(getResources().getStringArray(R.array.articles)[i]);
                //articleImg.setImageDrawable(getResources().getStringArray(R.array.articles)[i]);
                i--;
                }
                else i = getResources().getInteger(R.integer.totalArticles);
            }
        });
        nextB.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick (android.view.View view){
                if(i < getResources().getInteger(R.integer.totalArticles)){
                    //ImageView articleImg = findViewById(R.id.contentImage);
                    TextView articleTitle = findViewById(R.id.contentTopic);
                    TextView articleText = findViewById(R.id.contentArticle);
                    articleTitle.setText(getResources().getStringArray(R.array.titles)[i]);
                    articleText.setText(getResources().getStringArray(R.array.articles)[i]);
                    //articleImg.setImageDrawable(getResources().getStringArray(R.array.articles)[i]);
                    i++;
                }
                else i = 0;
            }
        });
        backB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                RelativeLayout OptLayout;
                OptLayout = findViewById(R.id.ArticlesPage);
                OptLayout.setVisibility(View.GONE);
            }
        });


    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */

    public native String stringFromJNI();
}