package com.intraining.subham.example;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {
    // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final View main = findViewById(R.id.MainPage);

        // Example of a call to a native method
        //TextView tv = (TextView) findViewById(R.id.sample_text);
        //tv.setText(stringFromJNI());


        //List of widgets for access
        final Button playB,settingB,quitB;
        final Switch tutorialToggle,musicToggle,hapticToggle,sfxToggle;
        final TextView saveSettingOption;




        //Allocation of widgets
        playB = findViewById(R.id.play);
        settingB= findViewById(R.id.settings);
        quitB = findViewById(R.id.quit);

        tutorialToggle = findViewById(R.id.tutorialSwitch);
        musicToggle = findViewById(R.id.musicSwitch);
        hapticToggle = findViewById(R.id.hapticSwitch);
        sfxToggle = findViewById(R.id.sfxSwitch);

        saveSettingOption = findViewById(R.id.saveOption);





        //Methods for widgets
        settingB.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                TableLayout OptLayout;
                OptLayout = findViewById(R.id.OptionsLayout);
                OptLayout.setVisibility(View.VISIBLE);
            }
        });

        hapticToggle.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(android.view.View view){
                if(main.isHapticFeedbackEnabled()){
                    main.setHapticFeedbackEnabled(false);
                    tutorialToggle.setHapticFeedbackEnabled(false);
                    musicToggle.setHapticFeedbackEnabled(false);
                    hapticToggle.setHapticFeedbackEnabled(false);
                    sfxToggle.setHapticFeedbackEnabled(false);
                    saveSettingOption.setHapticFeedbackEnabled(false);
                    playB.setHapticFeedbackEnabled(false);
                    settingB.setHapticFeedbackEnabled(false);
                    quitB.setHapticFeedbackEnabled(false);
                }
                else{
                    main.setHapticFeedbackEnabled(true);
                    tutorialToggle.setHapticFeedbackEnabled(true);
                    musicToggle.setHapticFeedbackEnabled(false);
                    hapticToggle.setHapticFeedbackEnabled(true);
                    sfxToggle.setHapticFeedbackEnabled(true);
                    saveSettingOption.setHapticFeedbackEnabled(true);
                    playB.setHapticFeedbackEnabled(true);
                    settingB.setHapticFeedbackEnabled(true);
                    quitB.setHapticFeedbackEnabled(true);
                }
            }
        });

        saveSettingOption.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(android.view.View view) {
                TableLayout OptLayout;
                OptLayout = findViewById(R.id.OptionsLayout);
                OptLayout.setVisibility(View.GONE);
            }
        });

    }

    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */

    public native String stringFromJNI();
}